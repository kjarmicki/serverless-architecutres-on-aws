exports.handle = function(event, context, callback) {
    callback(null, 'Hello from lambda');
};
